-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 14, 2015 at 11:42 AM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `lenden`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_name` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `cat_name`) VALUES
(1, 'Electronics'),
(2, 'Cosmetics'),
(3, 'Sports'),
(4, 'Car');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `detail` longtext COLLATE utf8_unicode_ci NOT NULL,
  `price` text COLLATE utf8_unicode_ci NOT NULL,
  `auth_id` text COLLATE utf8_unicode_ci NOT NULL,
  `cat_id` text COLLATE utf8_unicode_ci NOT NULL,
  `images` text COLLATE utf8_unicode_ci NOT NULL,
  `created_on` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `detail`, `price`, `auth_id`, `cat_id`, `images`, `created_on`) VALUES
(1, 'Guiter', 'This is my first guiter. I used it only 2 months. Now i wanna sell it to buy another one which looks more beautiful to me.', '18000', '1', '1', 'upload/555266f53650d.jpg', '2015-05-14'),
(2, 'Shari', 'asdjfsdlf sdj fklsdj fkl;asjdlfj las djfklasdjlfha;sdhjfh asdhf;hsdjk hfjasd hfjk;hasjfh as;hfjasdhjkl;fhasjl; fh;jkl;ahsdfjkl;hasdjklf hasd ;fhjsdh fjkl; hsdl hfl;ahd fhasdhfjklsdhfjklshd jlhas;l dhjasdh fhasdjk fhjsdh fjkl asdhfjklhsdjkl; fhjklsdh jkl;fhsjlhfjlhas;fhsjdh fjah jklhsdj;fhasdjh fj;hsdaj; fhasd', '5600', '1', '2', 'upload/55547c23ae916.jpg', '2015-05-14'),
(3, 'Cricket Bat', 'This is From London, My father send it to me just few days ago. Its a branded Bat and looks so attractive. I am not so interested to play cricket thats why i decided to sell it... If you want to buy you can contact with me,\r\n\r\nDont disturb. Only real buyer call', '4300', '1', '3', 'upload/555480b9860e7.jpg', '2015-05-14'),
(4, 'MicroLab M-223 2:1 Speaker', 'jsd flsdjlk fjklsdja;fkl jasklfj sdfkljaklfjfjkla fjkljsdakl;fj asdkl; jfklsdjklfjsdkl;fjsdklaj fkl;asj klfjsdakl fjasdklj fkl; fjasdkl jfakls;j dfkl;jsdklsdfjlk sd klasdkl fjasdkl jfklasjklfjasdkl jasdl;     \r\n \r\nsd dfjasj dlfjlsd jfklajklfjkl dksfklasj;\r\n\r\n asdfjjkldfsdj fsdaf asdj klsd', '2700', '1', '1', 'upload/5554847b044c3.jpg', '2015-05-14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `user` text COLLATE utf8_unicode_ci NOT NULL,
  `email` text COLLATE utf8_unicode_ci NOT NULL,
  `mobile` text COLLATE utf8_unicode_ci NOT NULL,
  `pass` text COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('superadmin','admin','user') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user`, `email`, `mobile`, `pass`, `role`) VALUES
(1, 'Kawsar Ahmed', 'kawsar', 'kaws.med@gmail.com', '1835649363', '8cb2237d0679ca88db6464eac60da96345513964', 'superadmin'),
(2, 'Abdur Karim', 'karim', 'karim@gmail.com', '1234567890', '8cb2237d0679ca88db6464eac60da96345513964', 'admin'),
(3, 'Abdur Rahim', 'rahim', 'rahim@gmail.com', '2147483647', '8cb2237d0679ca88db6464eac60da96345513964', 'user');
